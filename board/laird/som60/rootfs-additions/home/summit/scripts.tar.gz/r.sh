#!/bin/sh

rmmod lrdmwl_sdio
rmmod lrdmwl_usb
rmmod lrdmwl
rmmod mac80211
rmmod cfg80211
