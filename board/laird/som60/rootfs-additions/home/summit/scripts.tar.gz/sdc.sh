wpa_supplicant -B -D nl80211 -i wlan0 -c /home/summit/$1
