#!/bin/sh

wget http://10.16.74.166:8080/$1
