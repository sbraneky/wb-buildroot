#!/bin/sh


journalctl -t awm  --no-pager

