#!/bin/sh

fw_update http://10.16.74.166:8080/fw.txt
