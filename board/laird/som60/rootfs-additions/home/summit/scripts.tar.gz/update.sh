#!/bin/sh

fw_update /media/usb0/vw/60
